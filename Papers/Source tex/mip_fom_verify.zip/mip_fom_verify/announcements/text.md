How to exactly characterize the worst-case behavior of first-order methods in parametric convex optimization? We can use mixed-integer linear programming!

We exactly formulated the fixed-point residual as

Paper:
Code:

We borrow our main idea
