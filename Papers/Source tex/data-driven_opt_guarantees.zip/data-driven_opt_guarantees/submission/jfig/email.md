Subject: 2024 INFORMS JFIG Paper Competition

Content:
Dear Professors Epelman and Sim,

I am pleased to submit an application for the JFIG paper competition. Here is the information about the work:

a. Title of the paper: Data-Driven Performance Guarantees for Classical and Learned Optimizers

b. Names and affiliation of all authors on the paper:

1. Rajiv Sambharya, Princeton University, Department of Operations Research and Financial Engineering
2. Bartolomeo Stellato, Princeton University, Department of Operations Research and Financial Engineering

c. Date of PhD degree:

1. Rajiv Sambharya (not conferred yet)
2. Bartolomeo Stellato (3 Nov 2018)

d. I have reviewed eligibility requirements (A)—(I) and acknowledge that all co-authors meet the listed criteria.

e. Tools:
i. Optimization
vi. Machine Learning/Data Analytics

Application Area:
ix. Other: sparse coding, image processing, meta-learning.

Please do not hesitate to reach out if you have any questions about this submission.

Thank you very much for your consideration.

Best,
Bartolomeo
